package com.ashish.jpa.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.ashish.jpa.model.Department;
import com.ashish.jpa.model.Worker;

public class ManyToOne {

	public static void main(String[] args) {

		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Ashish_JPA");
		EntityManager entitymanager = emfactory.createEntityManager();
		entitymanager.getTransaction().begin();

		// Create Department Entity
		Department department = new Department();
		department.setName("Development");

		// Store Department
		entitymanager.persist(department);

		// Create Employee1 Entity
		Worker employee1 = new Worker();
		employee1.setWname("Sarish");
		employee1.setSalary(45000.0);
		employee1.setDeg("Technical Writer");
		employee1.setDepartment(department);

		// Create Employee2 Entity
		Worker employee2 = new Worker();
		employee2.setWname("Krishna");
		employee2.setSalary(45000.0);
		employee2.setDeg("Technical tester");
		employee2.setDepartment(department);

		// Create Employee3 Entity
		Worker employee3 = new Worker();
		employee3.setWname("Masthanvali");
		employee3.setSalary(50000.0);
		employee3.setDeg("Technical QA");
		employee3.setDepartment(department);

		// Store Employees
		entitymanager.persist(employee1);
		entitymanager.persist(employee2);
		entitymanager.persist(employee3);

		entitymanager.getTransaction().commit();
		entitymanager.close();
		emfactory.close();
	}
}