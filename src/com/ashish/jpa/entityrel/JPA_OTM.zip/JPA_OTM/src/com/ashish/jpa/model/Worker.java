package com.ashish.jpa.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Worker {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int wid;
	private String wname;
	private double salary;
	private String deg;

	public Worker(int wid, String wname, double salary, String deg) {
		super();
		this.wid = wid;
		this.wname = wname;
		this.salary = salary;
		this.deg = deg;
	}

	public Worker() {
		super();
	}

	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public String getWname() {
		return wname;
	}

	public void setWname(String wname) {
		this.wname = wname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDeg() {
		return deg;
	}

	public void setDeg(String deg) {
		this.deg = deg;
	}

}
